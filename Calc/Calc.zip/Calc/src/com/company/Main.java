package com.company;

public class Main {

    public static void main(String[] args) {
	Calc calc= new Calc(10,5);
    }
}
