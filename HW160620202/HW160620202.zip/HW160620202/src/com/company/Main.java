package com.company;

public class Main {

    public static int[] switchNumbers(int[] array){
        int counter=0;
        for(int i=0;i<array.length-1;i++){
            if (array[i] > array[i+1]) {
                int k=array[i+1];
                array[i+1]=array[i];
                array[i]=k;
                counter++;
            }
        }
        if(counter>0){
            switchNumbers(array);
        }
        return array;
    }

    public static int returnSmallestIndex(int[] array, int index1, int index2){
        int smallestNumberIndex=index1;
        for(int i=index1+1;i<=index2;i++){
            if(array[smallestNumberIndex]>array[i]){
                smallestNumberIndex=i;
            }
        }
        return smallestNumberIndex;
    }

    public static void main(String[] args) {
	int[] array={8,4,7,8,5,9};
        System.out.println(returnSmallestIndex(array,2,5));
        System.out.println("----------------------------------------");
	switchNumbers(array);
	for(int i=0;i<array.length;i++){
        System.out.println(array[i]);
    }
        System.out.println("----------------------------------------");
        System.out.println(returnSmallestIndex(array,0,5));
    }
}
