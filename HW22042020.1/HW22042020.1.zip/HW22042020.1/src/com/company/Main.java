package com.company;

public class Main {

    public static void PrintDate(String day, String month, String year){
        System.out.println(day + "-" + month + "-" + year);
        // Первый вид метода (я записал переменные как строчки, а не как числа, поскольку в ином случае нули просто удаляются, пример 01-06-2004 выдается в виде 1-6-2004)
    }

    public static void printDate(String day, String month, String year, String space){
        System.out.println(day + space + month + space + year);
    }

    public static void main(String[] args) {
	String day = "01";
	String month = "06";
	String year = "2004";
	System.out.println(day + "-" + month + "-" + year);
	PrintDate("01","06","2004");
	printDate("11", "11", "2011", "-");
	printDate("11", "11", "2011", "/");
    }
}
