package com.company;

public class Account {
    private String IBAN;
    private Person client;
    private double balance;

    public Account(Person client, double balance, String IBAN){
        this.client=client;
        this.balance=balance;
        this.IBAN=IBAN;
    }

    public String toString(){
        return "Client Name: "+client+"   Client's Balance: "+balance+"   IBAN: "+IBAN;
    }

    public String secureToString(){
        return "Client Name: "+client+"   Client's Balance: "+balance+"   IBAN: "+securedIBAN();
    }

    private String securedIBAN(){
        String str="";
        for (int i=0;IBAN.length()>i;i++){
            if (i>3 && i<IBAN.length()-2){
                str+="*";
            } else {
                str+=IBAN.charAt(i);
            }
        }
        return str;
    }

    public Person getClient() {
        return client;
    }

    public double getBalance() {
        return balance;
    }

    public String getIBAN() {
        return IBAN;
    }
}
