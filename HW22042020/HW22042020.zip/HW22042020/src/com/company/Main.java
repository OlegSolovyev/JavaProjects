package com.company;

public class Main {

    public static void minus(int a, int b){
        System.out.println("a minus b = " + (a-b));
    }

    public static void multiply(int a, int b){
        System.out.println("a multiply b = " + (a*b));
    }

    public static void main(String[] args) {
minus(100,50);
multiply(200,30);
    }
}
