package com.company;

public class Main {

    public static int judge(int a, int b){
        if (a != b){
            if (a>b){
                return a;
            } else {
                return b;
            }
        } else {
            System.out.println("they are equal");
            return 0;
        }
    }


    public static void main(String[] args) {

    int s=judge(111,11);
    System.out.println(s);

    }
}
