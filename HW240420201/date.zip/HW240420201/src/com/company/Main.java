package com.company;

public class Main {

    public static void PrintDate(int day, int month, int year, String sp){
        if (((day>0) & (day<31)) & ((month>0) & (month<12))){
            if (day > 9) {
                if (month>9){
                    System.out.println(day + sp + month + sp + year);
                } else {
                    System.out.println(day + sp + "0" + month + sp + year);
                }
            } else {
                if (month>9){
                    System.out.println("0" + day + sp + month + sp + year);

                } else {
                    System.out.println("0" + day + sp + "0" + month + sp + year);
                }
            }
        } else {
            System.out.println("ERROR, WRONG DATE");
        }
    }

    public static void main(String[] args) {
        PrintDate(1,60,2004, "/");
    }
}
